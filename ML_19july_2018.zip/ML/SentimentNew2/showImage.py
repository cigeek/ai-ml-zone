from PIL import Image

image = Image.open('plot.png')
image.show()

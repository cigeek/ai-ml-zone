package com.hackathon.prediction.function;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.commons.math3.stat.regression.SimpleRegression;

import com.hackathon.prediction.domain.ScenarioHis;
import com.hackathon.prediction.domain.ScenarioStockHis;
import com.hackathon.prediction.domain.ScenarioStockKey;
import com.hackathon.prediction.util.DateUtil;
import com.hackathon.prediction.domain.PredictedStockPrice;

public class LinearRegressionFn extends DoFn<KV<ScenarioStockKey,ScenarioStockHis>,PredictedStockPrice> {
	private String zeroDateString = "20170930";
	private String futureDateString = "20171230";
	public LinearRegressionFn(String zeroDateString, String futureDateString) {
		super();
		this.zeroDateString = zeroDateString;
		this.futureDateString = futureDateString;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 8634967430515283451L;
    @ProcessElement
    public void processElement(ProcessContext c) throws Exception {
    	KV<ScenarioStockKey, ScenarioStockHis> t = c.element();
    	ScenarioStockKey key = t.getKey();
		if (t == null || key == null) {
            return;
        }
//		try {
			SimpleRegression regression = new SimpleRegression();
			List<ScenarioHis> dataPointList = t.getValue().getHisPoints();
//			Collections.sort(dataPointList, new Comparator<ScenarioHis>() {
//
//				@Override
//				public int compare(ScenarioHis o1, ScenarioHis o2) {
//					return o1.getPriceDate().compareTo(o2.getPriceDate());
//				}
//			} );
			double[][] marketDataPoints = new double[dataPointList.size()][2];
			int i=0;
			for (ScenarioHis scenarioHis : dataPointList) {
					marketDataPoints[i][0] = new Double(DateUtil.getDayDiff(scenarioHis.getPriceDate(), zeroDateString));
					marketDataPoints[i][1] = Double.parseDouble(scenarioHis.getPrice());
					i++;
				}
			
			regression.addData(marketDataPoints);
			double predictedPrice =
					regression.predict(DateUtil.getDayDiff(zeroDateString, futureDateString));
			c.output(new PredictedStockPrice(key.getScenario(), key.getStockCode(), predictedPrice, futureDateString));
			
//		} catch (Exception e) {
//	    	e.printStackTrace();
//	    	return;
//    	}
    }

}

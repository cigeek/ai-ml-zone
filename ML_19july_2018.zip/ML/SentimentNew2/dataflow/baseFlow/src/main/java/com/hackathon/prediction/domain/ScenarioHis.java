package com.hackathon.prediction.domain;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

@DefaultCoder(AvroCoder.class)
public class ScenarioHis {

	private String scenario;
	private String stockCode;
	private String price;
	private String priceDate;
	
	
	// No-arg constructor for serialization
	private ScenarioHis() {}



	public ScenarioHis(String scenario, String stockCode, String price, String priceDate) {
		super();
		this.scenario = scenario;
		this.stockCode = stockCode;
		this.price = price;
		this.priceDate = priceDate;
	}
	
	

	@Override
	public String toString() {
		return "SenarioHis [scenario=" + scenario + ", stockCode=" + stockCode + ", price=" + price + ", priceDate="
				+ priceDate + "]";
	}

	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((priceDate == null) ? 0 : priceDate.hashCode());
		result = prime * result + ((scenario == null) ? 0 : scenario.hashCode());
		result = prime * result + ((stockCode == null) ? 0 : stockCode.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScenarioHis other = (ScenarioHis) obj;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (priceDate == null) {
			if (other.priceDate != null)
				return false;
		} else if (!priceDate.equals(other.priceDate))
			return false;
		if (scenario == null) {
			if (other.scenario != null)
				return false;
		} else if (!scenario.equals(other.scenario))
			return false;
		if (stockCode == null) {
			if (other.stockCode != null)
				return false;
		} else if (!stockCode.equals(other.stockCode))
			return false;
		return true;
	}



	public String getScenario() {
		return scenario;
	}

	public void setScenario(String scenario) {
		this.scenario = scenario;
	}

	public String getStockCode() {
		return stockCode;
	}

	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getPriceDate() {
		return priceDate;
	}

	public void setPriceDate(String priceDate) {
		this.priceDate = priceDate;
	}

}

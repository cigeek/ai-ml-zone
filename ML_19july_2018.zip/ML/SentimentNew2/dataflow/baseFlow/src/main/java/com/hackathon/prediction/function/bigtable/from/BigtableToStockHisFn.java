package com.hackathon.prediction.function.bigtable.from;

import java.util.Optional;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;

import com.google.bigtable.v2.Family;
import com.google.bigtable.v2.Row;
import com.hackathon.prediction.domain.StockHis;

public class BigtableToStockHisFn extends DoFn<Row,StockHis> {

    private final Counter tradeResultCounter = Metrics.counter(this.getClass(), "tradeResults");
    private final Counter zeroTradeResultCounter = Metrics.counter(this.getClass(), "tradeResults = zero/empty");

	
    @ProcessElement
    public void processElement(ProcessContext c) {
        tradeResultCounter.inc();
        // Here we strip the first character off the tradeID as it's had Z appended for some reason in the test data.
        // We expect ~ 136 reporting dates for a full result set.
        // The prices are an array of doubles in the avro file - we load them into an TimeStepResult object.



        final String[] stockCode = new String[1];
        final String[] priceDate = new String[1];
        final String[] price =  new String[1];

        // Our objects are now BT Row's.
        Row row = c.element();
        final Optional<Family> familyOptional = row
                .getFamiliesList()
                .stream()
                .filter(family -> family.getName().equals("STOCK_HIS"))
                .findFirst();

        if (!familyOptional.isPresent()) {
            return;
        }

        // Map the columns in the Row to the protobuff

        Family f = familyOptional.get();
        f.getColumnsList().forEach(col -> {
                String colName = col.getQualifier().toStringUtf8();
                switch(colName) {
                    case "stockCode":
                        stockCode[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "price":
                    	price[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "priceDate":
                        priceDate[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    default:
                        break;
                }
            });


        StockHis trade = new StockHis(stockCode[0], price[0], priceDate[0]);

        c.output(trade);
    }
}

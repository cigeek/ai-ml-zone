package com.hackathon.prediction;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.values.PCollection;
import org.apache.hadoop.hbase.client.Mutation;

import com.hackathon.prediction.domain.PriceMovement;

public class PriceMovementToBigtableTrans extends PTransform<PCollection<PriceMovement>,PCollection<Mutation>> {

	@Override
	public PCollection<Mutation> expand(PCollection<PriceMovement> input) {
		// TODO Auto-generated method stub
		return null;
	}





}

package com.hackathon.prediction.domain;

import java.math.BigDecimal;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;


@DefaultCoder(AvroCoder.class)
public class PricingResult  {
	private String tradeId;
	private String cptyId;
	private String scenario;
	private String timePoint;
	private BigDecimal mtm;
	private BigDecimal principal;
	
	public PricingResult(String tradeId, String cptyId, String scenario, String timePoint, BigDecimal mtm,
			BigDecimal principal) {
		super();
		this.tradeId = tradeId;
		this.cptyId = cptyId;
		this.scenario = scenario;
		this.timePoint = timePoint;
		this.mtm = mtm;
		this.principal = principal;
	}
	public PricingResult() {}
	
	public BigDecimal getPrincipal() {
		return principal;
	}
	public void setPrincipal(BigDecimal principal) {
		this.principal = principal;
	}
	public String getTradeId() {
		return tradeId;
	}
	public void setTradeId(String tradeId) {
		this.tradeId = tradeId;
	}
	public String getCptyId() {
		return cptyId;
	}
	public void setCptyId(String cptyId) {
		this.cptyId = cptyId;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getTimePoint() {
		return timePoint;
	}
	public void setTimePoint(String timePoint) {
		this.timePoint = timePoint;
	}
	public BigDecimal getMtm() {
		return mtm;
	}
	public void setMtm(BigDecimal mtm) {
		this.mtm = mtm;
	}
	public String toString() {
		return tradeId+" "+cptyId+" "+scenario+" "+timePoint+" "+mtm;
	};
}

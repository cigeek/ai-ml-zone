package com.hackathon.prediction.function.bigtable.to;

import org.apache.hadoop.hbase.client.Mutation;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.shaded.org.apache.commons.lang.StringUtils;

import com.hackathon.prediction.domain.ScenarioHis;

public class ScenarioHisToBigTableFn extends BaseToBigtableFn<ScenarioHis,Mutation> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1564283494133371156L;

	@ProcessElement
    public void processElement(ProcessContext c) {
		ScenarioHis sh = c.element();
		String stockIdStr = StringUtils.leftPad(sh.getStockCode(),4,'#');
		String priceDate = StringUtils.leftPad(sh.getPriceDate(),13,'0');
		String rowKey=sh.getScenario()+","+stockIdStr+","+priceDate;
		Put put = new Put(rowKey.getBytes());
		String family = "STOCK_HIS_CUTDOWN";
		addColumn(put, family, "scenario", sh.getScenario());
		addColumn(put, family, "stockCode", sh.getStockCode());
		addColumn(put, family, "price", sh.getPrice());
		addColumn(put, family, "priceDate", sh.getPriceDate());
		c.output(put);
	}

}

import tensorflow as tf
import csv
import numpy as np

#x1_data = [1, 0, 3, 0, 5]
#x2_data = [0, 2, 0, 4, 0]
#y_data = [1, 2, 3, 4, 5]
x1_data=[]
x2_data=[]
y_data=[]
with open('Dataset.csv') as csvfile:
    readCSV=csv.reader(csvfile,delimiter=',')
    for row in readCSV:
        x1_data.extend([float(row[0])])
        x2_data.extend([float(row[1])])
        y_data.extend([float(row[2])])

print x1_data
print x2_data
print y_data

W1 = tf.Variable(tf.random_uniform([1], -1.0, 1.0))
W2 = tf.Variable(tf.random_uniform([1], -1.0, 1.0))
b = tf.Variable(tf.random_uniform([1], -1.0, 1.0))

hypothesis = W1 * x1_data + W2 * x2_data + b

cost = tf.reduce_mean(tf.square(hypothesis - y_data))

a = tf.Variable(0.1)
optimizer = tf.train.GradientDescentOptimizer(a)
train = optimizer.minimize(cost)

init = tf.global_variables_initializer()

sess = tf.Session()
sess.run(init)

for step in xrange(2001):
    sess.run(train)
    if step % 20 == 0:
      #  print step, sess.run(cost), sess.run(W1), sess.run(W2), sess.run(b)
        w1=sess.run(W1)
        w2=sess.run(W2)
        B=sess.run(b)

# print w1, w2, B
x1_test=[]
x2_test=[]
y_test=[]
with open('Test.csv') as csvfile:
    readCSV=csv.reader(csvfile,delimiter=',')
    for row in readCSV:
        x1_test.extend([float(row[0])])
        x2_test.extend([float(row[1])])
      #  y_test.extend([float(W1*row[0]+W2*row[1]+b)])

y_test=w1*x1_test+w2*x2_test+B
# print y_test

X = np.empty([0,3])
for i in range(0, len(x1_test)):
   row_new = [x1_test[i], x2_test[i], y_test[i]]
   X=np.vstack([X,row_new])

with open('Output.csv','wb') as csvWriteFile:
    writeCSV=csv.writer(csvWriteFile,delimiter=",")
    writeCSV.writerows(X)

print X

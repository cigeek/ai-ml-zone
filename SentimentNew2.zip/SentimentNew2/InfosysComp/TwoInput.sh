
python mainModel.py prev_Dataset.csv 2 Tr_Out_NN.csv DT.png NA NA 1000 1

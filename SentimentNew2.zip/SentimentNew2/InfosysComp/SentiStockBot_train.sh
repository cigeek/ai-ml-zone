python SentimentFinal.py

python mainModel.py

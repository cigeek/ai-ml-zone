package com.hackathon.prediction.domain;

import java.util.ArrayList;
import java.util.List;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

@DefaultCoder(AvroCoder.class)
public class ScenarioStockHis {
	private String ScenarioNum;
	private String StockCode;
	private List<ScenarioHis> hisPoints = new ArrayList<ScenarioHis>();

	public ScenarioStockHis() {
	}

	public String getScenarioNum() {
		return ScenarioNum;
	}

	public void setScenarioNum(String senarioNum) {
		ScenarioNum = senarioNum;
	}

	public List<ScenarioHis> getHisPoints() {
		return hisPoints;
	}

	public void setHisPoints(List<ScenarioHis> hisPoints) {
		this.hisPoints = hisPoints;
	}

	public String getStockCode() {
		return StockCode;
	}

	public void setStockCode(String stockCode) {
		StockCode = stockCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ScenarioNum == null) ? 0 : ScenarioNum.hashCode());
		result = prime * result + ((StockCode == null) ? 0 : StockCode.hashCode());
		result = prime * result + ((hisPoints == null) ? 0 : hisPoints.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScenarioStockHis other = (ScenarioStockHis) obj;
		if (ScenarioNum == null) {
			if (other.ScenarioNum != null)
				return false;
		} else if (!ScenarioNum.equals(other.ScenarioNum))
			return false;
		if (StockCode == null) {
			if (other.StockCode != null)
				return false;
		} else if (!StockCode.equals(other.StockCode))
			return false;
		if (hisPoints == null) {
			if (other.hisPoints != null)
				return false;
		} else if (!hisPoints.equals(other.hisPoints))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Scenario [ScenarioNum=" + ScenarioNum + ", StockCode=" + StockCode + ", hisPoints=" + hisPoints + "]";
	}

}

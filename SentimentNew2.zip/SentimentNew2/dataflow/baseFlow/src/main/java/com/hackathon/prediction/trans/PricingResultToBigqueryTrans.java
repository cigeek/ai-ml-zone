package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.google.api.services.bigquery.model.TableRow;
import com.hackathon.prediction.domain.PricingResult;
import com.hackathon.prediction.function.bigquery.to.PricingResultToBigqueryFn;

public class PricingResultToBigqueryTrans extends PTransform<PCollection<PricingResult>, PCollection<TableRow>> {

	@Override
	public PCollection<TableRow> expand(PCollection<PricingResult> input) {
		return input.apply("toSenarioHis", ParDo.of(new PricingResultToBigqueryFn()));
	}


}

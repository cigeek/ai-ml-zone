/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hackathon.prediction;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.bigtable.BigtableIO;
import org.apache.beam.sdk.io.gcp.bigtable.BigtableIO.Read;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.shaded.org.apache.commons.lang.StringUtils;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;
import com.google.cloud.bigtable.beam.CloudBigtableScanConfiguration;
import com.google.cloud.bigtable.config.BigtableOptions;
import com.hackathon.prediction.domain.Event;
import com.hackathon.prediction.domain.PredictedStockPrice;
import com.hackathon.prediction.domain.PriceMovement;
import com.hackathon.prediction.domain.PricingResult;
import com.hackathon.prediction.domain.Scenario;
import com.hackathon.prediction.domain.ScenarioHis;
import com.hackathon.prediction.domain.ScenarioScope;
import com.hackathon.prediction.domain.ScenarioStockHis;
import com.hackathon.prediction.domain.ScenarioStockKey;
import com.hackathon.prediction.domain.SentimentScore;
import com.hackathon.prediction.domain.StockHis;
import com.hackathon.prediction.domain.Trade;
import com.hackathon.prediction.domain.TrainData;
import com.hackathon.prediction.function.combine.PredictedPriceCollectFn;
import com.hackathon.prediction.function.combine.ScenarioStockHisCollectFn;
import com.hackathon.prediction.function.combine.TrainDataCollectFn;
import com.hackathon.prediction.io.FileTextIO;
import com.hackathon.prediction.trans.HisToEventTrans;
import com.hackathon.prediction.trans.NewsToEventTrans;
import com.hackathon.prediction.trans.PredictPriceTrans;
import com.hackathon.prediction.trans.PricingResultToBigqueryTrans;
import com.hackathon.prediction.trans.SentimentAnalysisTrans;
import com.hackathon.prediction.trans.SentimentToStringTrans;
import com.hackathon.prediction.trans.StockHisFromBigTableTrans;
import com.hackathon.prediction.trans.StringDelimitByCommaToBigtableRow;
import com.hackathon.prediction.trans.StringToPriceMovementTrans;
import com.hackathon.prediction.trans.TradeFromBigqueryTrans;
import com.hackathon.prediction.util.DateUtil;



public class StreamingPipeline {
	private static final String ZeroDateString = "20170930";
	private static final String FutureDateString = "20171230";


  
  static final StringDelimitByCommaToBigtableRow TRADE_MUTATION = new StringDelimitByCommaToBigtableRow() {

	@Override
	protected Put putRow(String[] attributes) {
		String family = "TRADE";
		String qualifier;
		String rowKey = attributes[1]+"-"+attributes[0];
		Put put = new Put(rowKey.getBytes());
		for (int i = 0; i < attributes.length; i++) {
			switch (i) {
			case 0:					
				qualifier = "tradeId";
				break;
			case 1:					
				qualifier = "stockCode";
				break;
			case 2:					
				qualifier = "quantity";
				break;
			case 3:					
				qualifier = "orderType";
				break;
			case 4:					
				qualifier = "price";
				break;
			case 5:					
				qualifier = "priceDate";
				break;
			default:
				qualifier = "";
				break;
			}
			String value = attributes[i];
			addColumn(put, family, qualifier, value);
		}
		return put;
	}};

    
	

	static final StringDelimitByCommaToBigtableRow MARKET_MUTATION = new StringDelimitByCommaToBigtableRow() {

		@Override
		protected Put putRow(String[] attributes) {
			String family = "STOCK_HIS";
			String qualifier;
			String rowKey = attributes[0]+","+StringUtils.leftPad(attributes[7],4,'#');
			Put put = new Put(rowKey.getBytes());
			for (int i = 0; i < attributes.length; i++) {
				String value = attributes[i];
				switch (i) {
				case 0:					
					qualifier = "priceDate";
					addColumn(put, family, qualifier, value);
					break;
				case 1:					
					break;
				case 2:					
					break;
				case 3:					
					break;
				case 4:					
					qualifier = "price";
					addColumn(put, family, qualifier, value);
					break;
				case 5:
					break;
				case 6:					
					break;
				case 7:					
					qualifier = "stockCode";
					addColumn(put, family, qualifier, value);
					break;
				default:
					qualifier = "";
					break;
				}
			}
			return put;
		}

	};
		
		

		

	

  public static void main(String[] args) throws Exception {
	DataflowPipelineOptions options =
				 PipelineOptionsFactory.fromArgs(args).withValidation().as(DataflowPipelineOptions.class);
    
    Pipeline p;
    options.setJobName("load-data");
//    options.setNumWorkers(5);
//    options.setWorkerDiskType("compute.googleapis.com/projects//europe-west1-c//diskTypes/pd-ssd");
//    options.setWorkerMachineType("n1-highmem-4");
    options.setRegion("europe-west1");
    options.setZone("europe-west1-c");
//    options.setDiskSizeGb(100);
    p = Pipeline.create(options);

//load CSV
    CloudBigtableScanConfiguration tradeBigTableconfig = new CloudBigtableScanConfiguration.Builder()
    	    .withProjectId("tr-elastic-compute")
    	    .withInstanceId("hello-bigtable")
    	    .withTableId("TRADE")
    	    .build();
    
    CloudBigtableScanConfiguration marketBigTableconfig = new CloudBigtableScanConfiguration.Builder()
    	    .withProjectId("tr-elastic-compute")
    	    .withInstanceId("hello-bigtable")
    	    .withTableId("STOCK_HIS")
    	    .build();
    
    CloudBigtableScanConfiguration cutdownBigTableconfig = new CloudBigtableScanConfiguration.Builder()
    		.withProjectId("tr-elastic-compute")
    		.withInstanceId("hello-bigtable")
    		.withTableId("STOCK_HIS_CUTDOWN")
    		.build();

    CloudBigtableScanConfiguration scenarioBigTableconfig = new CloudBigtableScanConfiguration.Builder()
    		.withProjectId("tr-elastic-compute")
    		.withInstanceId("hello-bigtable")
    		.withTableId("STOCK_SCEN")
    		.build();
    
    
    List<TableFieldSchema> fields = new ArrayList<>();
    fields.add(new TableFieldSchema().setName("TradeId").setType("STRING"));
    fields.add(new TableFieldSchema().setName("CptyId").setType("STRING"));
    fields.add(new TableFieldSchema().setName("Scenario").setType("STRING"));
    fields.add(new TableFieldSchema().setName("TimePoint").setType("STRING"));
    fields.add(new TableFieldSchema().setName("MTM").setType("FLOAT"));
    fields.add(new TableFieldSchema().setName("Principal").setType("FLOAT"));
    TableSchema pricingSchema = new TableSchema().setFields(fields);
    
    
    List<TableFieldSchema> cutdownFields = new ArrayList<>();
    cutdownFields.add(new TableFieldSchema().setName("ScenarioID").setType("STRING"));
    cutdownFields.add(new TableFieldSchema().setName("ScenarioDate").setType("STRING"));
    TableSchema cutdownSchema = new TableSchema().setFields(cutdownFields);
    
//    PDone tradeLoadingEnd = p.apply("ReadTradeCSVs", TextIO.read().from("gs://sean-li-bucket/trade_set/test/*"))
//	.apply("InsertTradeIntoBigTable", ParDo.of(TRADE_MUTATION))
//	.apply(CloudBigtableIO.writeToTable(tradeBigTableconfig));
//    
//    PDone marketDataLoadingEnd = p.apply("ReadMarkDataCSVs", TextIO.read().from("gs://sean-li-bucket/market_data/*"))
//	.apply("InsertMarketDataIntoBigTable", ParDo.of(MARKET_MUTATION))
//	.apply(CloudBigtableIO.writeToTable(marketBigTableconfig));
    
    PCollection<String> priceString = p.apply("Load price CSVs", TextIO.read().from("gs://ml_bucket_rwa/movement/*"));
    
    PCollection<PriceMovement> priceMovements = priceString.apply("to Price Movement",new StringToPriceMovementTrans());
    
    
    PCollection<KV<String, String>> hisFromFiles = p.apply("Load Article CSVs", FileTextIO.readFilepattern("gs://ml_bucket_rwa/Articles/*"));
    
    p.run().waitUntilFinish();
    
	PCollection<Event> events = hisFromFiles.apply("File to Event",new HisToEventTrans());

	PCollection<SentimentScore> sentimentScores = events.apply("Sentiment Analysis", new SentimentAnalysisTrans());

	
	PCollection<KV<String, TrainData>> sentimentScoreKV = sentimentScores.apply("Sentiment Score to KV", ParDo.of(new DoFn<SentimentScore, KV<String,TrainData>>() {
					@ProcessElement
					public void processElement(DoFn<SentimentScore, KV<String,TrainData>>.ProcessContext c) throws Exception {
						SentimentScore ss = c.element();
						c.output(KV.of(ss.getEventId(), new TrainData(ss.getEventId(), ss.getScore(), 0)));
					}
				}));
	
	
	
    PCollection<KV<String, TrainData>> priceMovementKV = priceMovements.apply("Price Movement to KV",ParDo.of(new DoFn<PriceMovement, KV<String,TrainData>>() {
					@ProcessElement
					public void processElement(DoFn<PriceMovement, KV<String,TrainData>>.ProcessContext c) throws Exception {
						PriceMovement pm = c.element();
						c.output(KV.of(pm.getEventId(), new TrainData(pm.getEventId(), 0, pm.getMovement())));
					}
				}));
	
    PCollectionList<KV<String, TrainData>> collection = PCollectionList.of(sentimentScoreKV).and(priceMovementKV);
    
    PCollection<KV<String, TrainData>> merged = collection.apply(Flatten.<KV<String, TrainData>>pCollections());
    
    PCollection<KV<String, TrainData>> apply = merged.apply("Collect Train Data", Combine.perKey(new TrainDataCollectFn()));
    
    
//    merged.apply("",new  TrainDataToBigTableTrans());
    
    
//  PCollection<Mutation> sentimentScoreMutaion = sentimentScores.apply("Sentiment to Bigtable", new SentimentScoreToBigtableTrans());
//    
//  PCollection<Mutation> priceMovementMutation = priceMovements.apply("Price movement to Bigtable",new PriceMovementToBigtableTrans());

//	PCollectionList<Mutation> collection = PCollectionList.of(sentimentScoreMutaion).and(priceMovementMutation);
//	
//	PCollection<Mutation> merged = collection.apply(Flatten.<Mutation>pCollections());
	
//	merged.apply(CloudBigtableIO.writeToTable(tradeBigTableconfig));
    
    
	
	
	PCollection<String> news = p.apply("ReadPubSub", PubsubIO.readStrings().fromTopic(""));
	
	PCollection<Event> event = news.apply("News to Event",new NewsToEventTrans());
	
	PCollection<SentimentScore> imediateSentiment = event.apply("Sentiment Analysis", new SentimentAnalysisTrans());
	
	imediateSentiment.apply("",new SentimentToStringTrans())
	.apply("Push to Pub Sub",PubsubIO.writeStrings());
	
	

    
    //new pipeline for market data cutdown
    options.setJobName("prediction");
//    options.setNumWorkers(10);
//    options.setWorkerDiskType("compute.googleapis.com/projects//europe-west1-c//diskTypes/pd-ssd");
//    options.setWorkerMachineType("n1-highmem-4");
    options.setRegion("europe-west1");
    options.setZone("europe-west1-c");
//    options.setDiskSizeGb(100);
    p = Pipeline.create(options);
    
	final int scenarioCount = 1000;
	String inputString1 = "20071101";
	String inputString2 = "20170930";
	
	int i;
	
	ArrayList<String> senarioList = generateCutDownDateList(scenarioCount, inputString1, inputString2);
	
	
	BigtableOptions.Builder bigtableOptionsBuilder =
			new BigtableOptions.Builder()
			.setProjectId("tr-elastic-compute")
			.setInstanceId("hello-bigtable");
	
	
	PCollection<String> senarioCutdownDate = p.apply(Create.of(senarioList)).setCoder(StringUtf8Coder.of());
	
		PCollectionView<List<ScenarioScope>> senarioDateView = senarioCutdownDate.apply("toScope", ParDo.of(new DoFn<String, ScenarioScope>() {
			@ProcessElement
			public void processElement(DoFn<String, ScenarioScope>.ProcessContext c) throws Exception {
				String line = c.element();
				String[] scenarioAttributes = line.split(",");
				String scenarioNum = scenarioAttributes[0];
				String inputDate = scenarioAttributes[1];
				ScenarioScope senarioDate = new ScenarioScope(scenarioNum,inputDate);
				c.output(senarioDate);
			}

		})).apply("View.asList", View.asList());
	
	
		Read stockHisBigtableOption = BigtableIO.read()
				.withBigtableOptions(bigtableOptionsBuilder)
				.withTableId("STOCK_HIS");
		
		 PCollection<ScenarioHis> scenarioHis = p.apply("readBigtable", stockHisBigtableOption)
		 .apply("BigtableToStockHis", new StockHisFromBigTableTrans())
		 .apply("StockHistoSenarioHis", ParDo.of(new DoFn<StockHis, ScenarioHis>() {
					@ProcessElement
					public void processElement(DoFn<StockHis, ScenarioHis>.ProcessContext c) throws Exception {
						StockHis stockHis = c.element();
						List<ScenarioScope> sideInput = c.sideInput(senarioDateView);

						for (ScenarioScope SenarioScope : sideInput) {
							String inputDate = SenarioScope.getInputDate();
							if (stockHis.getPriceDate().compareTo(inputDate) > 0) {
								c.output(new ScenarioHis(SenarioScope.getScenarioNum(), stockHis.getStockCode(),
										stockHis.getPrice(), stockHis.getPriceDate()));
							}
						}

					}
				}).withSideInputs(senarioDateView));
		 
		PCollection<KV<ScenarioStockKey, ScenarioHis>> apply2 = scenarioHis.apply("Key by scenario and stock ID",ParDo.of(new DoFn<ScenarioHis,KV<ScenarioStockKey,ScenarioHis>>() {
             @ProcessElement
             public void processElement(ProcessContext c) {
            	 ScenarioHis hisPoint = c.element();
                 if (hisPoint == null || hisPoint.getStockCode() == null) {
                     return;
                 }
                 KV<ScenarioStockKey,ScenarioHis> mapped = KV.of(new ScenarioStockKey(hisPoint.getScenario(),hisPoint.getStockCode()), hisPoint);
                 c.output(mapped);
             }
         }));
		PCollection<KV<ScenarioStockKey, ScenarioStockHis>> apply3 = apply2
		 .apply("Collect cutdown result", Combine.perKey(new ScenarioStockHisCollectFn()));
		
		PCollection<PredictedStockPrice> scenarioPredictPrice = apply3
		 .apply("Predict Furture Price", new PredictPriceTrans(ZeroDateString,FutureDateString));

		
		 PCollectionView<Map<String, Scenario>> scenariosView = scenarioPredictPrice
		.apply("Key stock ID",ParDo.of(new DoFn<PredictedStockPrice,KV<String,PredictedStockPrice>>() {
            @ProcessElement
            public void processElement(ProcessContext c) {
            	PredictedStockPrice pridectedPrice = c.element();
                if (pridectedPrice == null || pridectedPrice.getStockCode() == null) {
                    return;
                }
                KV<String,PredictedStockPrice> mapped = KV.of(pridectedPrice.getStockCode(), pridectedPrice);
                c.output(mapped);
            }
        }))
		.apply("Collect predicted price result",Combine.perKey(new PredictedPriceCollectFn()))
		.apply("View.asMap", View.asMap());
//
//	

	;
	
// pricing
    Read tradeBigtableRead = BigtableIO.read()
  	      .withBigtableOptions(bigtableOptionsBuilder)
  	      .withTableId("TRADE");
    
  	p.apply("read",tradeBigtableRead)
  	.apply("to Trade",new TradeFromBigqueryTrans())
  	.apply("Pricing",ParDo.of(new DoFn<Trade, PricingResult>() {
		@ProcessElement
		public void processElement(DoFn<Trade, PricingResult>.ProcessContext c) throws Exception {
			Trade trade = c.element();
			Map<String, Scenario> sideInput = c.sideInput(scenariosView);
			Scenario scenario = sideInput.get(trade.getStockCode());
			List<PredictedStockPrice> scenarioPrices = scenario.getScenarioPrices();
			for (PredictedStockPrice predictedStockPrice : scenarioPrices) {
//				BigDecimal pricingResult = PricingUtils.priceStock(new BigDecimal(trade.getPrice()), new BigDecimal(predictedStockPrice.getPrice()), new BigDecimal(trade.getQuantity()), "Short".equalsIgnoreCase(trade.getOrderType()));
//				c.output(new PricingResult(trade.getTradeId(), trade.getStockCode(), predictedStockPrice.getScenario(), "20171230", pricingResult, new BigDecimal(trade.getQuantity()).multiply(new BigDecimal(trade.getPrice()))));
			}
		}
	}).withSideInputs(scenariosView))
  	.apply("to Bigquery Table Row", new PricingResultToBigqueryTrans())
  	.apply("InsertBigQuery",BigQueryIO.writeTableRows()
				.withSchema(pricingSchema)
				.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_TRUNCATE)
				.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
				.to("tr-elastic-compute:prediction.PricingResult"));
	
  	
	senarioCutdownDate.apply("ToTableRow", ParDo.of(new DoFn<String, TableRow>() {
		@ProcessElement
		public void processElement(DoFn<String, TableRow>.ProcessContext c) throws Exception {
			String senarioCutdownDateStr = c.element();
			String[] senarioCutdownDateAttr = senarioCutdownDateStr.split(",");
			TableRow tableRow = new TableRow();
			tableRow
			.set("ScenarioID", senarioCutdownDateAttr[0])
			.set("ScenarioDate", senarioCutdownDateAttr[1]);
			c.output(tableRow);
		}
	}))
	.apply("InsertBigQuery",BigQueryIO.writeTableRows()
			.withSchema(cutdownSchema)
			.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_TRUNCATE)
			.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
			.to("tr-elastic-compute:prediction.Scenario"));	
	
//    p.run().waitUntilFinish();
    


//     options.setJobName("aggregation");
//     p = Pipeline.create(options);
//     
//     p.apply("Aggregate",BigQueryIO.read().from("SELECT TimePoint BUSINESS_DATE, CptyId STOCK_CODE, AVG(mtm) PREDICTED_PNL FROM ( SELECT CptyId, Scenario,  TimePoint, sum(mtm) AS mtm FROM [tr-elastic-compute:hackathon.PricingResult] GROUP BY CptyId, Scenario, TimePoint ) GROUP BY BUSINESS_DATE,STOCK_CODE"))
//  		.apply("InsertBigQuery",BigQueryIO.writeTableRows()
//  				.withSchema(schema)
//  				.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_TRUNCATE)
//  				.withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
//  				.to("tr-elastic-compute:hackathon.PricingResult"));
//     .apply("Format",ParDo.of(new DoFn<TableRow, String>() {
//		@ProcessElement
//		public void processElement(ProcessContext c) {
//			TableRow tableRow = c.element();
//			String stockId = (String) tableRow.get("Stock_id");
//			String balance = (String) tableRow.get("Balance");
//			c.output(stockId+" : "+balance);
//		}
//	}))
//    .apply("SaveResult", TextIO.write().to("gs://sean-li-bucket/result-mix"));
     
     
		
//    p.run().waitUntilFinish();

  }

private static ArrayList<String> generateCutDownDateList(final int scenarioCount, String inputString1,
		String inputString2) throws Exception, ParseException {
	int diff = DateUtil.getDayDiff(inputString1, inputString2);
	
	SimpleDateFormat myFormat = new SimpleDateFormat("yyyyMMdd");
	Calendar c1 = Calendar.getInstance();
	c1.setTime(myFormat.parse(inputString1));
	
	int i = 1;
	ArrayList<String> senarioList = new ArrayList<String>();
	while (i <= scenarioCount) {
		int randomNum = ThreadLocalRandom.current().nextInt(0, diff);
		Calendar randomDate = (Calendar) c1.clone();
		randomDate.add(Calendar.DATE, randomNum);
		String randomDateString = myFormat.format(randomDate.getTime());
		String snum = StringUtils.leftPad(Integer.valueOf(i).toString(), 4, '0');
		senarioList.add("SENARIO"+snum+","+randomDateString);
		i++;
	}
	return senarioList;
}
}

package com.hackathon.prediction.function.bigtable.to;

import org.apache.hadoop.hbase.client.Mutation;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.shaded.org.apache.commons.lang.StringUtils;

import com.hackathon.prediction.domain.PredictedStockPrice;

public class ScenarioStockPriceToBigTableFn extends BaseToBigtableFn<PredictedStockPrice,Mutation> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1564283494133371156L;

	@ProcessElement
    public void processElement(ProcessContext c) {
		PredictedStockPrice predictedPrice = c.element();
		String rowKey = StringUtils.leftPad(predictedPrice.getStockCode(), 4, '#') + "," + predictedPrice.getScenario();
		Put put = new Put(rowKey.getBytes());
		String family = "STOCK_SCEN";
		addColumn(put, family, "stockCode", predictedPrice.getStockCode());
		addColumn(put, family, "scenario", predictedPrice.getScenario());
		addColumn(put, family, "price", new Double(predictedPrice.getPrice()).toString());
		addColumn(put, family, "priceDate", predictedPrice.getPriceDate());
		c.output(put);
	}
}

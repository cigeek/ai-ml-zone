package com.hackathon.prediction.function;

import org.apache.beam.sdk.transforms.DoFn;

public class NewsToEventFn extends DoFn {

}

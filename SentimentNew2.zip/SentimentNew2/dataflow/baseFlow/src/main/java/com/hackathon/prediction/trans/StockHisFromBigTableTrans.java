package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.google.bigtable.v2.Row;
import com.hackathon.prediction.domain.StockHis;
import com.hackathon.prediction.function.bigtable.from.BigtableToStockHisFn;
import com.hackathon.prediction.function.bigtable.to.ScenarioHisToBigTableFn;


public class StockHisFromBigTableTrans extends PTransform<PCollection<Row>,PCollection<StockHis>> {


	@Override
	public PCollection<StockHis> expand(PCollection<Row> input) {
		return input.apply("toSenarioHis", ParDo.of(new BigtableToStockHisFn()));
	}

}

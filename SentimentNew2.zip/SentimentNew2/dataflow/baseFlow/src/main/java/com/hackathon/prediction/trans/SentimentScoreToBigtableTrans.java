package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.values.PCollection;
import org.apache.hadoop.hbase.client.Mutation;

import com.hackathon.prediction.domain.SentimentScore;

public class SentimentScoreToBigtableTrans extends PTransform<PCollection<SentimentScore>,PCollection<Mutation>>{

	@Override
	public PCollection<Mutation> expand(PCollection<SentimentScore> input) {
		return null;
	}

}

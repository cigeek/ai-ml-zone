package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.hackathon.prediction.domain.SentimentScore;
import com.hackathon.prediction.function.SentimentScoreToStringFn;

public class SentimentToStringTrans extends PTransform<PCollection<SentimentScore>,PCollection<String>> {

	@Override
	public PCollection<String> expand(PCollection<SentimentScore> input) {
		 return input.apply("toPriceMovement", ParDo.of(new SentimentScoreToStringFn()));
	}



}

package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.hadoop.hbase.client.Mutation;

import com.hackathon.prediction.domain.ScenarioHis;
import com.hackathon.prediction.function.bigtable.to.ScenarioHisToBigTableFn;

public class SenarioHisToBigTableTrans extends PTransform<PCollection<ScenarioHis>,PCollection<Mutation>> {

	@Override
	public PCollection<Mutation> expand(PCollection<ScenarioHis> input) {
		return input.apply("toSenarioHis", ParDo.of(new ScenarioHisToBigTableFn()));
	}



}

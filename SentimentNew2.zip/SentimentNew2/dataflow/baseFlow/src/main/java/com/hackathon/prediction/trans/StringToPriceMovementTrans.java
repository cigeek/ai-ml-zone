package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.hackathon.prediction.domain.PriceMovement;
import com.hackathon.prediction.function.StringToPriceMovementFn;

public class StringToPriceMovementTrans extends PTransform<PCollection<String>,PCollection<PriceMovement>> {

	@Override
	public PCollection<PriceMovement> expand(PCollection<String> input) {
		 return input.apply("toPriceMovement", ParDo.of(new StringToPriceMovementFn()));
	}



}

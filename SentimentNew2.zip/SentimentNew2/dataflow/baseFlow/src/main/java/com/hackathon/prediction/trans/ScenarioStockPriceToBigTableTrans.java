package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.hadoop.hbase.client.Mutation;

import com.hackathon.prediction.domain.PredictedStockPrice;
import com.hackathon.prediction.function.bigtable.to.ScenarioStockPriceToBigTableFn;

public class ScenarioStockPriceToBigTableTrans
		extends PTransform<PCollection<PredictedStockPrice>, PCollection<Mutation>> {

	@Override
	public PCollection<Mutation> expand(PCollection<PredictedStockPrice> input) {
		return input.apply("to Predicted Price", ParDo.of(new ScenarioStockPriceToBigTableFn()));
	}

}

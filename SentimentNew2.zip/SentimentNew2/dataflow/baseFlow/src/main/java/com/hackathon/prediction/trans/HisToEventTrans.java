package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import com.hackathon.prediction.domain.Event;
import com.hackathon.prediction.function.SentimentAnalysisFn;

public class HisToEventTrans extends PTransform<PCollection<KV<String, String>>, PCollection<Event>> {

	@Override
	public PCollection<Event> expand(PCollection<KV<String, String>> input) {
		return input.apply("toPriceMovement", ParDo.of(new SentimentAnalysisFn()));
	}



}

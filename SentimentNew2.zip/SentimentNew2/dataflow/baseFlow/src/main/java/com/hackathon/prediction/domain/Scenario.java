package com.hackathon.prediction.domain;

import java.util.ArrayList;
import java.util.List;

import org.apache.avro.reflect.Nullable;
import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
@DefaultCoder(AvroCoder.class)
public class Scenario {
	private String stockCode;
	private List<PredictedStockPrice> scenarioPrices = new ArrayList<PredictedStockPrice>();

	public Scenario() {
	}

	public String getStockCode() {
		return stockCode;
	}

	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}

	public List<PredictedStockPrice> getScenarioPrices() {
		return scenarioPrices;
	}

	public void setScenarioPrices(List<PredictedStockPrice> scenarioPrices) {
		this.scenarioPrices = scenarioPrices;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((scenarioPrices == null) ? 0 : scenarioPrices.hashCode());
		result = prime * result + ((stockCode == null) ? 0 : stockCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Scenario other = (Scenario) obj;
		if (scenarioPrices == null) {
			if (other.scenarioPrices != null)
				return false;
		} else if (!scenarioPrices.equals(other.scenarioPrices))
			return false;
		if (stockCode == null) {
			if (other.stockCode != null)
				return false;
		} else if (!stockCode.equals(other.stockCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Scenario [stockCode=" + stockCode + ", scenarioPrices=" + scenarioPrices + "]";
	}

}

package com.hackathon.prediction.function.combine;

import org.apache.beam.sdk.transforms.Combine.CombineFn;

import com.hackathon.prediction.domain.TrainData;

public class TrainDataCollectFn extends CombineFn<TrainData, TrainData, TrainData> {

	@Override
	public TrainData createAccumulator() {
		return new TrainData();
	}

	@Override
	public TrainData addInput(TrainData accumulator, TrainData input) {
		accumulator = input;
		return accumulator;
	}

	@Override
	public TrainData mergeAccumulators(Iterable<TrainData> accumulators) {
		TrainData merged = createAccumulator();
		for (TrainData trainData : accumulators) {
			if ((trainData.getEvent_id()!=null)&&(trainData.getScore()!=0)) {
				merged.setScore(trainData.getScore());
			} else if ((trainData.getEvent_id()!=null)&&(trainData.getMovement()!=0)) {
				merged.setMovement(trainData.getMovement());
			}
		}
		return merged;
	}

	@Override
	public TrainData extractOutput(TrainData accumulator) {
		return accumulator;
	}




}

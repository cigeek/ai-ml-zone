package com.hackathon.prediction.function;

import org.apache.beam.sdk.transforms.DoFn;

public class HisToEventFn extends DoFn {

}

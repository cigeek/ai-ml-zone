package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.hadoop.hbase.client.Mutation;

import com.hackathon.prediction.domain.TrainData;
import com.hackathon.prediction.function.TrainDataToBigTableFn;

public class TrainDataToBigTableTrans extends PTransform<PCollection<TrainData>,PCollection<Mutation>> {

	@Override
	public PCollection<Mutation> expand(PCollection<TrainData> input) {
		return input.apply("toTrainData", ParDo.of(new TrainDataToBigTableFn()));
	}



}

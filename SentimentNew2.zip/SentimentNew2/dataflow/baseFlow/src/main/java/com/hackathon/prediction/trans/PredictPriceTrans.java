package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;

import com.hackathon.prediction.domain.ScenarioStockHis;
import com.hackathon.prediction.domain.ScenarioStockKey;
import com.hackathon.prediction.domain.PredictedStockPrice;
import com.hackathon.prediction.function.LinearRegressionFn;

public class PredictPriceTrans
		extends PTransform<PCollection<KV<ScenarioStockKey, ScenarioStockHis>>, PCollection<PredictedStockPrice>> {
	private String zeroDateString;
	private String futureDateString;

	public PredictPriceTrans(String zeroDateString, String futureDateString) {
		super();
		this.zeroDateString = zeroDateString;
		this.futureDateString = futureDateString;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -673387328850408751L;

	@Override
	public PCollection<PredictedStockPrice> expand(PCollection<KV<ScenarioStockKey, ScenarioStockHis>> input) {
		return input.apply("linearRegression", ParDo.of(new LinearRegressionFn(zeroDateString, futureDateString)));
	}

}

package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.google.bigtable.v2.Row;
import com.hackathon.prediction.domain.Trade;
import com.hackathon.prediction.function.bigtable.to.BigtableToTradeFn;

public class TradeFromBigqueryTrans extends PTransform<PCollection<Row>,PCollection<Trade>> {

	@Override
	public PCollection<Trade> expand(PCollection<Row> input) {
		return input.apply("toSenarioHis", ParDo.of(new BigtableToTradeFn()));
	}



}

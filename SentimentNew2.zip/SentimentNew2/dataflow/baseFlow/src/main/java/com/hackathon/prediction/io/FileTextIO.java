package com.hackathon.prediction.io;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.util.NoSuchElementException;

import org.apache.beam.sdk.coders.Coder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.FileBasedSource;
import org.apache.beam.sdk.io.Read;
import org.apache.beam.sdk.io.fs.MatchResult.Metadata;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.ValueProvider;
import org.apache.beam.sdk.options.ValueProvider.StaticValueProvider;
import org.apache.beam.sdk.util.CoderUtils;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileTextIO {
	// Match TextIO.
	public static Read.Bounded<KV<String,String>> readFilepattern(String filepattern) {
		
	    return Read.from(new FileSource(StaticValueProvider.of(filepattern), 1));
	}

	
	
	public static class FileSource extends FileBasedSource<KV<String,String>> {
	    private String filename = null;

//	    public FileSource(String fileOrPattern, long minBundleSize) {
//	        super(fileOrPattern, minBundleSize);
//	    }


	public FileSource(ValueProvider fileOrPatternSpec, long minBundleSize) {
		super(fileOrPatternSpec, minBundleSize);
		// TODO Auto-generated constructor stub
	}
	    
		public FileSource(Metadata fileMetadata, long minBundleSize, long startOffset, long endOffset) {
			super(fileMetadata, minBundleSize, startOffset, endOffset);
			this.filename = filename;
		}

		// This will indicate that there is no intra-file splitting.
	    @Override
	    public boolean isSplittable(){
	        return false;
	    }

	    public boolean producesSortedKeys(PipelineOptions options) throws Exception {
	        return false;
	    }

	    @Override
	    public void validate() {}

	    @Override
	    public Coder<KV<String,String>> getDefaultOutputCoder() {
	        return KvCoder.of(StringUtf8Coder.of(),StringUtf8Coder.of());
	    }

	    @Override
	    public FileBasedReader<KV<String,String>> createSingleFileReader(PipelineOptions options) {
	        return new FileReader(this);
	    }

		@Override
		protected FileBasedSource<KV<String, String>> createForSubrangeOfFile(Metadata fileMetadata, long start,
				long end) {
			return new FileSource(fileMetadata, getMinBundleSize(), start, end);
		}
	}

	/**
	 * A reader that should read entire file of text from a {@link FileSource}.
	 */
	private static class FileReader extends FileBasedSource.FileBasedReader<KV<String,String>> {
	    private static final Logger LOG = LoggerFactory.getLogger(FileReader.class);
	    private ReadableByteChannel channel = null;
	    private long nextOffset = 0;
	    private long currentOffset = 0;
	    private boolean isAtSplitPoint = false;
	    private final ByteBuffer buf;
	    private static final int BUF_SIZE = 1024;
	    private KV<String,String> currentValue = null;
	    private String filename;

	    public FileReader(FileSource source) {
	        super(source);
	        buf = ByteBuffer.allocate(BUF_SIZE);
	        buf.flip();
	        this.filename = source.filename;
	    }

	    private int readFile(ByteArrayOutputStream out) throws IOException {
	        int byteCount = 0;
	        while (true) {
	            if (!buf.hasRemaining()) {
	                buf.clear();
	                int read = channel.read(buf);
	                if (read < 0) {
	                    break;
	                }
	                buf.flip();
	            }
	            byte b = buf.get();
	            byteCount++;

	            out.write(b);
	        }
	        return byteCount;
	    }

	    @Override
	    protected void startReading(ReadableByteChannel channel) throws IOException {
	        this.channel = channel;
	    }

	    @Override
	    protected boolean readNextRecord() throws IOException {
	        currentOffset = nextOffset;

	        ByteArrayOutputStream buf = new ByteArrayOutputStream();
	        int offsetAdjustment = readFile(buf);
	        if (offsetAdjustment == 0) {
	            // EOF
	            return false;
	        }
	        nextOffset += offsetAdjustment;
	        isAtSplitPoint = true;
	        currentValue = KV.of(this.filename,CoderUtils.decodeFromByteArray(StringUtf8Coder.of(), buf.toByteArray()));
	        return true;
	    }

	    @Override
	    protected boolean isAtSplitPoint() {
	        return isAtSplitPoint;
	    }

	    @Override
	    protected long getCurrentOffset() {
	        return currentOffset;
	    }

	    @Override
	    public KV<String,String> getCurrent() throws NoSuchElementException {
	        return currentValue;
	    }
	}

	}

package com.hackathon.prediction.trans;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;

import com.hackathon.prediction.domain.Event;
import com.hackathon.prediction.domain.SentimentScore;
import com.hackathon.prediction.function.SentimentScoreToStringFn;

public class SentimentAnalysisTrans extends PTransform<PCollection<Event>, PCollection<SentimentScore>> {


	@Override
	public PCollection<SentimentScore> expand(PCollection<Event> input) {
		// TODO Auto-generated method stub
		return input.apply("toPriceMovement", ParDo.of(new SentimentScoreToStringFn()));
	}

}

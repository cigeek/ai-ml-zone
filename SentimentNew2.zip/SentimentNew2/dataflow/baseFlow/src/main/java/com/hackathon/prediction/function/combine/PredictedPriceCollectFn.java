package com.hackathon.prediction.function.combine;

import java.util.List;

import org.apache.beam.sdk.transforms.Combine.CombineFn;

import com.hackathon.prediction.domain.PredictedStockPrice;
import com.hackathon.prediction.domain.Scenario;



public class PredictedPriceCollectFn extends CombineFn<PredictedStockPrice, Scenario, Scenario> {

	@Override
	public Scenario createAccumulator() {
		return new Scenario();
	}

	@Override
	public Scenario addInput(Scenario accumulator, PredictedStockPrice input) {
		setStockCodeNumIfNull(accumulator,input.getStockCode());
		accumulator.getScenarioPrices().add(input);
		return accumulator;
	}


	@Override
	public Scenario mergeAccumulators(Iterable<Scenario> accumulators) {
		Scenario merged = createAccumulator();
		for (Scenario scenario : accumulators) {			
			setStockCodeNumIfNull(merged,scenario.getStockCode());
			List<PredictedStockPrice> scenarioPrices = scenario.getScenarioPrices();
			merged.getScenarioPrices().addAll(scenarioPrices);
		}
		return merged;
	}

	@Override
	public Scenario extractOutput(Scenario accumulator) {
		return accumulator;
	}

	private void setStockCodeNumIfNull(Scenario accumulator, String stockCode) {
		if (accumulator.getStockCode() == null) {
			accumulator.setStockCode(stockCode);
		}
		
	}


}

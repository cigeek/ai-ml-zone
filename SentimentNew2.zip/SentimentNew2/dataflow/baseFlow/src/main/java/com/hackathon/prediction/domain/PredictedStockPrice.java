package com.hackathon.prediction.domain;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

@DefaultCoder(AvroCoder.class)
public class PredictedStockPrice {
	private String scenario;
	private String stockCode;
	private double price;
	private String priceDate;
	public PredictedStockPrice() {
		super();
	}
	public PredictedStockPrice(String scenario, String stockCode, double price, String priceDate) {
		super();
		this.scenario = scenario;
		this.stockCode = stockCode;
		this.price = price;
		this.priceDate = priceDate;
	}
	
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getPriceDate() {
		return priceDate;
	}
	public void setPriceDate(String priceDate) {
		this.priceDate = priceDate;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((priceDate == null) ? 0 : priceDate.hashCode());
		result = prime * result + ((scenario == null) ? 0 : scenario.hashCode());
		result = prime * result + ((stockCode == null) ? 0 : stockCode.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PredictedStockPrice other = (PredictedStockPrice) obj;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (priceDate == null) {
			if (other.priceDate != null)
				return false;
		} else if (!priceDate.equals(other.priceDate))
			return false;
		if (scenario == null) {
			if (other.scenario != null)
				return false;
		} else if (!scenario.equals(other.scenario))
			return false;
		if (stockCode == null) {
			if (other.stockCode != null)
				return false;
		} else if (!stockCode.equals(other.stockCode))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ScenarioStockPrice [scenario=" + scenario + ", stockCode=" + stockCode + ", price=" + price
				+ ", priceDate=" + priceDate + "]";
	}
}

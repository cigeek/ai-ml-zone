package com.hackathon.prediction.function.combine;

import java.util.List;

import org.apache.beam.sdk.transforms.Combine.CombineFn;

import com.hackathon.prediction.domain.ScenarioStockHis;
import com.hackathon.prediction.domain.ScenarioHis;

public class ScenarioStockHisCollectFn extends CombineFn<ScenarioHis, ScenarioStockHis, ScenarioStockHis> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4163302110162077290L;

	@Override
	public ScenarioStockHis createAccumulator() {
		return new ScenarioStockHis();
	}

	@Override
	public ScenarioStockHis addInput(ScenarioStockHis accumulator, ScenarioHis input) {
		setScenarioIfNull(accumulator, input.getScenario());
		setStockCodeIfNull(accumulator,input.getStockCode());
		accumulator.getHisPoints().add(input);
		return accumulator;
	}


	@Override
	public ScenarioStockHis mergeAccumulators(Iterable<ScenarioStockHis> accumulators) {
		ScenarioStockHis merged = createAccumulator();
		for (ScenarioStockHis scenario : accumulators) {
			setScenarioIfNull(merged, scenario.getScenarioNum());
			setStockCodeIfNull(merged,scenario.getStockCode());
			List<ScenarioHis> hisPoints = scenario.getHisPoints();
			merged.getHisPoints().addAll(hisPoints);
		}
		return merged;
	}

	@Override
	public ScenarioStockHis extractOutput(ScenarioStockHis accumulator) {
		return accumulator;
	}

	private void setScenarioIfNull(ScenarioStockHis accumulator, String scenario) {
		if (accumulator.getScenarioNum() == null) {
			accumulator.setScenarioNum(scenario);
		}
	}


	private void setStockCodeIfNull(ScenarioStockHis accumulator, String stockCode) {
		if (accumulator.getStockCode() == null) {
			accumulator.setStockCode(stockCode);
		}
	}
}

package com.hackathon.prediction.function.bigquery.to;

import org.apache.beam.sdk.transforms.DoFn;

import com.google.api.services.bigquery.model.TableRow;
import com.hackathon.prediction.domain.PricingResult;

public class PricingResultToBigqueryFn extends DoFn<PricingResult,TableRow> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ProcessElement
    public void processElement(ProcessContext c) {
		PricingResult pricingResult = c.element();
		TableRow tableRow = new TableRow();
		tableRow
		.set("TradeId", pricingResult.getTradeId())
		.set("CptyId", pricingResult.getCptyId())
		.set("Scenario", pricingResult.getScenario())
		.set("TimePoint", pricingResult.getTimePoint())
		.set("MTM", pricingResult.getMtm())
		.set("Principal", pricingResult.getPrincipal())
		;
		c.output(tableRow);
	}

}

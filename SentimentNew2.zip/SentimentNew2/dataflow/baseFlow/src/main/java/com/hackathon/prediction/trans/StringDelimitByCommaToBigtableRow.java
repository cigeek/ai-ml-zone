package com.hackathon.prediction.trans;

public abstract class StringDelimitByCommaToBigtableRow extends StringToBigtableRow {
	protected String getDelimiter() {
		return ",";
	}
}

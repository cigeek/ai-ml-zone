python SentimentModule.py
python multilinear_main.py
echo ------------------------------------------------------------------------------------
echo ------------------------------------------------------------------------------------
echo Your Comments:
cat hypothetical_test.txt
echo ------------------------------------------------------------------------------------
echo Sentiment score, magnitude:
cat hypothetical_sentiment.csv
echo ------------------------------------------------------------------------------------
echo Stock price change, in %, if your comment was the general sentiment:
cat Output.csv

echo ------------------------------------------------------------------------------------

python mainModel.py Keen.csv 1 Keen_pred.csv Keen.png NA NA 10 1

python mainModel2.py CNS.csv 17 CNS_pred.csv CNS.png NA NA 3001 1

sudo pip install wheel
sudo pip install pandas
sudo pip install Keras
sudo pip install -U scikit-learn
sudo pip install matplotlib;
sudo apt-get install python-tk;

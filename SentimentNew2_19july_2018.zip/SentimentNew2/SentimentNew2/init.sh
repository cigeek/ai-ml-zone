export GOOGLE_APPLICATION_CREDENTIALS=private_key.json;
sudo pip install matplotlib;
sudo apt-get install python-tk;

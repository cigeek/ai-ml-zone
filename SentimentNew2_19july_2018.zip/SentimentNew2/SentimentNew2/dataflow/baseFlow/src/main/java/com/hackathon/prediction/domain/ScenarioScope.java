package com.hackathon.prediction.domain;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

@DefaultCoder(AvroCoder.class)
public class ScenarioScope {
	String scenarioNum;
	String inputDate;
	
	
	// No-arg constructor for serialization
	private ScenarioScope() {}
	
	@Override
	public String toString() {
		return "SenarioScope [scenarioNum=" + scenarioNum + ", inputDate=" + inputDate + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((inputDate == null) ? 0 : inputDate.hashCode());
		result = prime * result + ((scenarioNum == null) ? 0 : scenarioNum.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScenarioScope other = (ScenarioScope) obj;
		if (inputDate == null) {
			if (other.inputDate != null)
				return false;
		} else if (!inputDate.equals(other.inputDate))
			return false;
		if (scenarioNum == null) {
			if (other.scenarioNum != null)
				return false;
		} else if (!scenarioNum.equals(other.scenarioNum))
			return false;
		return true;
	}
	public ScenarioScope(String scenarioNum, String inputDate) {
		super();
		this.scenarioNum = scenarioNum;
		this.inputDate = inputDate;
	}
	public String getScenarioNum() {
		return scenarioNum;
	}
	public void setScenarioNum(String scenarioNum) {
		this.scenarioNum = scenarioNum;
	}
	public String getInputDate() {
		return inputDate;
	}
	public void setInputDate(String inputDate) {
		this.inputDate = inputDate;
	}
	
	
}

package com.hackathon.prediction.function.bigtable.to;

import java.util.Optional;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;

import com.google.bigtable.v2.Family;
import com.google.bigtable.v2.Row;
import com.hackathon.prediction.domain.Trade;

public class BigtableToTradeFn extends DoFn<Row,Trade> {
    private final Counter tradeResultCounter = Metrics.counter(this.getClass(), "tradeResults");
    private final Counter zeroTradeResultCounter = Metrics.counter(this.getClass(), "tradeResults = zero/empty");

	
    @ProcessElement
    public void processElement(ProcessContext c) {
        tradeResultCounter.inc();
        // Here we strip the first character off the tradeID as it's had Z appended for some reason in the test data.
        // We expect ~ 136 reporting dates for a full result set.
        // The prices are an array of doubles in the avro file - we load them into an TimeStepResult object.


        final String[] tradeId = new String[1];
        final String[] stockCode = new String[1];
        final String[] quantity = new String[1];
        final String[] orderType = new String[1];
        final String[] price =  new String[1];
        final String[] priceDate = new String[1];

        // Our objects are now BT Row's.
        Row row = c.element();
        final Optional<Family> familyOptional = row
                .getFamiliesList()
                .stream()
                .filter(family -> family.getName().equals("TRADE"))
                .findFirst();

        if (!familyOptional.isPresent()) {
            return;
        }

        // Map the columns in the Row to the protobuff

        Family f = familyOptional.get();
        f.getColumnsList().forEach(col -> {
                String colName = col.getQualifier().toStringUtf8();
                switch(colName) {
                    case "tradeId":
                    	tradeId[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "stockCode":
                        stockCode[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "quantity":
                    	quantity[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "orderType":
                    	orderType[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "price":
                    	price[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    case "priceDate":
                        priceDate[0] = col.getCells(0).getValue().toStringUtf8();
                        break;
                    default:
                        break;
                }
            });


        Trade trade = new Trade(tradeId[0],stockCode[0],quantity[0],orderType[0],Double.valueOf(price[0]), priceDate[0]);

        c.output(trade);
    }
}

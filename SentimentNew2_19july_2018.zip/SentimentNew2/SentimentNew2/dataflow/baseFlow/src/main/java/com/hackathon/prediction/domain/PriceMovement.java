package com.hackathon.prediction.domain;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

@DefaultCoder(AvroCoder.class)
public class PriceMovement {
	private String eventId;
	private double movement;
	
	
	
	public PriceMovement(String eventId, double movement) {
		super();
		this.eventId = eventId;
		this.movement = movement;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
		long temp;
		temp = Double.doubleToLongBits(movement);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PriceMovement other = (PriceMovement) obj;
		if (eventId == null) {
			if (other.eventId != null)
				return false;
		} else if (!eventId.equals(other.eventId))
			return false;
		if (Double.doubleToLongBits(movement) != Double.doubleToLongBits(other.movement))
			return false;
		return true;
	}


	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public double getMovement() {
		return movement;
	}
	public void setMovement(double movement) {
		this.movement = movement;
	}


	@Override
	public String toString() {
		return "PriceMovement [eventId=" + eventId + ", movement=" + movement + "]";
	}
	
	
	
}

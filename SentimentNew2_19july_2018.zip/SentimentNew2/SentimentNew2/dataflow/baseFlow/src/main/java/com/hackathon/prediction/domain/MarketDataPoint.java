package com.hackathon.prediction.domain;

public class MarketDataPoint {
	private double price;
	private double priceDate;
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getPriceDate() {
		return priceDate;
	}
	public void setPriceDate(double priceDate) {
		this.priceDate = priceDate;
	}
}

package com.hackathon.prediction.function.bigtable.to;

import java.math.BigDecimal;
import java.nio.ByteBuffer;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public abstract class BaseToBigtableFn<InputT, OutputT> extends DoFn<InputT, OutputT> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -987741853149985778L;

	protected void addColumn(Put put, Object family, Object qualifier, Object value) {
		byte[] FAMILY = null;
		byte[] QUALIFIER = null;
		byte[] VALUE = null;
		
		if (family instanceof String) {
			FAMILY = Bytes.toBytes((String)family);
		}else if (family instanceof BigDecimal) {
			FAMILY = Bytes.toBytes((BigDecimal)family);
		}else if (family instanceof Double) {
			FAMILY = Bytes.toBytes((Double)family);
		} else if (family instanceof Integer) {
			FAMILY = Bytes.toBytes((Integer)family);
		} else if (family instanceof Boolean) {
			FAMILY = Bytes.toBytes((Boolean)family);
		} else if (family instanceof Float) {
			FAMILY = Bytes.toBytes((Float)family);
		} else if (family instanceof Long) {
			FAMILY = Bytes.toBytes((Long)family);
		} else if (family instanceof Short) {
			FAMILY = Bytes.toBytes((Short)family);
		} else if (family instanceof ByteBuffer) {
			FAMILY = Bytes.toBytes((ByteBuffer)family);
		} 
		
		if (qualifier instanceof String) {
			QUALIFIER = Bytes.toBytes((String)qualifier);
		}else if (qualifier instanceof BigDecimal) {
			QUALIFIER = Bytes.toBytes((BigDecimal)qualifier);
		}else if (qualifier instanceof Double) {
			QUALIFIER = Bytes.toBytes((Double)qualifier);
		} else if (qualifier instanceof Integer) {
			QUALIFIER = Bytes.toBytes((Integer)qualifier);
		} else if (qualifier instanceof Boolean) {
			QUALIFIER = Bytes.toBytes((Boolean)qualifier);
		} else if (qualifier instanceof Float) {
			QUALIFIER = Bytes.toBytes((Float)qualifier);
		} else if (qualifier instanceof Long) {
			QUALIFIER = Bytes.toBytes((Long)qualifier);
		} else if (qualifier instanceof Short) {
			QUALIFIER = Bytes.toBytes((Short)qualifier);
		} else if (qualifier instanceof ByteBuffer) {
			QUALIFIER = Bytes.toBytes((ByteBuffer)qualifier);
		} 
		
		if (value instanceof String) {
			VALUE = Bytes.toBytes((String)value);
		}else if (value instanceof BigDecimal) {
			VALUE = Bytes.toBytes((BigDecimal)value);
		}else if (value instanceof Double) {
			VALUE = Bytes.toBytes((Double)value);
		} else if (value instanceof Integer) {
			VALUE = Bytes.toBytes((Integer)value);
		} else if (value instanceof Boolean) {
			VALUE = Bytes.toBytes((Boolean)value);
		} else if (value instanceof Float) {
			VALUE = Bytes.toBytes((Float)value);
		} else if (value instanceof Long) {
			VALUE = Bytes.toBytes((Long)value);
		} else if (value instanceof Short) {
			VALUE = Bytes.toBytes((Short)value);
		} else if (value instanceof ByteBuffer) {
			VALUE = Bytes.toBytes((ByteBuffer)value);
		} 
		
		put.addColumn(FAMILY, QUALIFIER, VALUE);
	}

}

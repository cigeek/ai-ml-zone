package com.hackathon.prediction.domain;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;

@DefaultCoder(AvroCoder.class)
public class ScenarioStockKey {
	private String scenario;
	private String stockCode;

	public ScenarioStockKey() {
	}

	public ScenarioStockKey(String scenario, String stockCode) {
		super();
		this.scenario = scenario;
		this.stockCode = stockCode;
	}

	public String getScenario() {
		return scenario;
	}

	public void setScenario(String scenario) {
		this.scenario = scenario;
	}

	public String getStockCode() {
		return stockCode;
	}

	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((scenario == null) ? 0 : scenario.hashCode());
		result = prime * result + ((stockCode == null) ? 0 : stockCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScenarioStockKey other = (ScenarioStockKey) obj;
		if (scenario == null) {
			if (other.scenario != null)
				return false;
		} else if (!scenario.equals(other.scenario))
			return false;
		if (stockCode == null) {
			if (other.stockCode != null)
				return false;
		} else if (!stockCode.equals(other.stockCode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ScenarioStock [scenario=" + scenario + ", stockCode=" + stockCode + "]";
	}

}

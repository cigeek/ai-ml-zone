package com.hackathon.prediction.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class DateUtil {

	public static int getDayDiff(String date1, String date2) throws Exception {
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyyMMdd");
		
		Calendar c1 = Calendar.getInstance();
		c1.setTime(myFormat.parse(date1));
		Calendar c2 = Calendar.getInstance();
		c2.setTime(myFormat.parse(date2));
	
		int diff = (int) (TimeUnit.DAYS.convert(c2.getTimeInMillis() - c1.getTimeInMillis(), TimeUnit.MILLISECONDS));
		
		return diff;
	}

}
